import React from 'react'
import ReactDOM from 'react-dom'

import DriftApp from './app'

ReactDOM.render(<DriftApp />, document.getElementById('app'))
