# React_-styling-with-css-modules
# react-drift

Example app for React Component styling

## Styling methods
- CSS modules

## Install

npm install
```

## Run

```
npm start
open http://localhost:3000
```


